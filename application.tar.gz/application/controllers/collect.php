<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Collect extends CI_Controller {

    function __construct() {
        parent::__construct();
    }

    public function index() {

        $this->load->view('template');
    }

    public function boosts() {
        
    }

    public function item() {
        
    }

    public function modifier() {
        
    }

    public function thing() {
        
    }

}

/* End of file collect.php */
/* Location: ./application/controllers/collect.php */