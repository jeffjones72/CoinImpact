<?php
class MissionsRequiredEvent extends CI_Model {
    
}
?>