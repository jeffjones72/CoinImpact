<?php
class PlayerBossItem extends ItemInstance {
    public function getClassification() {
        return 'item';
    }
}
?>