<?php
class PlayerThing extends CI_Model {
    
}
?>