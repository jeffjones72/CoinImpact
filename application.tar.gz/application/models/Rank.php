<?php
class Rank extends CI_Model {
    
}
?>