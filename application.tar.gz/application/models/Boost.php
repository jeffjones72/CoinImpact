<?php
class Boost extends CI_Model {
    
}
?>