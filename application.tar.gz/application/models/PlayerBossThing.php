<?php
class PlayerBossThing extends CI_Model {
    public function getClassification() {
        return 'thing';
    }
}
?>