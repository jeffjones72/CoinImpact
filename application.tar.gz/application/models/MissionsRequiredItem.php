<?php
class MissionsRequiredItem extends CI_Model {
    
}
?>