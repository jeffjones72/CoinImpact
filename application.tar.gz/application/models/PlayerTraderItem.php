<?php
class PlayerTraderItem extends CI_Model {
    
}
?>