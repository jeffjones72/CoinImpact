<?php
class MissionsRequiredCombatant extends CI_Model {
    
}
?>