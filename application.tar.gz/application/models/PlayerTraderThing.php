<?php
class PlayerTraderThing extends CI_Model {
    
}
?>
