<?php
class Players_repo extends CI_Model {
    private $cache;
    function __construct() {
        // Call the Model constructor
        parent::__construct();
    }
    public function get_by_id($id) {
        
    }
}
?>