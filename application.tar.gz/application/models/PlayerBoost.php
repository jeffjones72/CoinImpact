<?php
class PlayerBoost extends CI_Model {
    
}
?>