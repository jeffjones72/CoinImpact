<?php
class MissionsRequiredThing extends CI_Model {
    
}
?>