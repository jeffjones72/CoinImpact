<?php
class Globals {
    const DATE_FORMAT = "Y-m-d H:i:s";
    const MYSQL_DATE_FORMAT = "Y-m-d H:i:s";
}
?>