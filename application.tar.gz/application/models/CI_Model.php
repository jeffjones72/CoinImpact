<?php
include(BASEPATH.'core/Model.php');
?>