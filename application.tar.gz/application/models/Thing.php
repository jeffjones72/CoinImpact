<?php
class Thing extends CI_Model {
    public function getClassification() {
        return 'thing';
    }
}
?>