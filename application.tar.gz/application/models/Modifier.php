<?php
class Modifier extends CI_Model {
    
}
?>