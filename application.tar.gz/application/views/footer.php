<div id="footer">
    <div style="text-align:center;">
        &copy; Copyright 2013, COIN IMPACT, by 
        <a href="http://downrangegames.com">Down Range Games</a>
        . All Rights Reserved.
    </div>
    <div id="w3c">
        <a href="http://validator.w3.org/check?uri={{request.build_absolute_uri|urlencode}}%3Fsession_key={{request.session_key}}&amp;ss=1"
           title="valid html5">xhtml</a>
        <a href="http://jigsaw.w3.org/css-validator/check/referer?profile=css3"
           title="valid css">css</a>
    </div>
    <div class="clear"></div>
</div>
</body>
</html>