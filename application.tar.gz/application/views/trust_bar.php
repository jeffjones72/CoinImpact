<?php
/*
 * CI:B0211
* Trust bar with coins left; 
* it is calculated in controller action, function  accept_trader
*/
?>
			<div class="exploreCoinsBar">
				<div class="exploreProgress" style="width:<?=$player->trustProgress?>%;"></div>
				<div class="exploreProgressText">
					<strong>Coins </strong> - $<?=$player->balance?> left <?php ?></div>
			</div>