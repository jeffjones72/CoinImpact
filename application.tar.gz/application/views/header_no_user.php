<!DOCTYPE html>
<html>
    <head>
        <meta name="copyright" content="Copyright (C) 2012 Down Range Games, Inc, 1084 Paloma Rd., Monterey, CA 93940" />
        <meta content="text/html; charset=utf-8" http-equiv="Content-type" />
        <script type="text/javascript" src="<?php echo base_url(); ?>_scripts/jquery-1.9.1.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>_scripts/password_strength_plugin.js"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>_css/styles.css" media="screen" />
        <title><?php echo $page_title; ?></title>
        <script type="text/javascript" src="<?php echo base_url(); ?>_scripts/functions.js"></script>
    </head>