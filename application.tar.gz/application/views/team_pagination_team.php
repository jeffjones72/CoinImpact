                <div class="page-number">
                    <b>1-8</b> of <b>24</b>
                </div>
                <div class="page-button-container">
                    <img class="page-button" src="<?php echo base_url(); ?>_images/page-prev-disabled.png" /><img class="page-button page-button-last" src="<?php echo base_url(); ?>_images/page-next.png" />
                </div>
